"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Plus, Shield } from "lucide-react"
import { UsuariosTable } from "@/components/admin/usuarios-table"
import { UsuarioModal } from "@/components/admin/usuario-modal"
import { UsuarioDeleteDialog } from "@/components/admin/usuario-delete-dialog"
import type { Usuario } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"

interface AdminPageContentProps {
  usuarios: Usuario[]
}

export default function AdminPageContent({ usuarios: initialUsuarios }: AdminPageContentProps) {
  const { toast } = useToast()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedUsuario, setSelectedUsuario] = useState<Usuario | null>(null)
  
  // Adicionar usuário de exemplo
  const usuarioExemplo: Usuario = {
    id: "1",
    email: "admin.sistema",
    nome_completo: "Administrador",
    cargo: "admin",
    ativo: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    ultimo_acesso: new Date().toISOString(),
  }
  
  const [usuarios] = useState<Usuario[]>([...initialUsuarios, usuarioExemplo])
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Dialog de exclusão
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [usuarioToDelete, setUsuarioToDelete] = useState<Usuario | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  // Função para refetch dos dados
  const refetchUsuarios = async () => {
    setIsRefreshing(true)
    try {
      // TODO: Fetch real do backend
      // const response = await fetch('/api/admin/usuarios')
      // const data = await response.json()
      // setUsuarios(data)
      
      console.log("🔄 Refetch de usuários (mock)")
      // Mock: apenas simula
      await new Promise(resolve => setTimeout(resolve, 300))
    } catch (error) {
      console.error("❌ Erro ao recarregar usuários:", error)
    } finally {
      setIsRefreshing(false)
    }
  }

  const handleOpenCreateModal = () => {
    setSelectedUsuario(null)
    setIsModalOpen(true)
  }

  const handleOpenEditModal = (usuario: Usuario) => {
    setSelectedUsuario(usuario)
    setIsModalOpen(true)
  }

  const handleCloseModal = async () => {
    setIsModalOpen(false)
    setSelectedUsuario(null)
    await refetchUsuarios()
  }

  const handleOpenDeleteDialog = (usuario: Usuario) => {
    setUsuarioToDelete(usuario)
    setIsDeleteDialogOpen(true)
  }

  const handleCloseDeleteDialog = () => {
    setIsDeleteDialogOpen(false)
    setUsuarioToDelete(null)
  }

  const handleConfirmDelete = async () => {
    if (!usuarioToDelete) return

    setIsDeleting(true)
    try {
      console.log("🗑️ Excluindo usuário:", usuarioToDelete.id)
      
      // TODO: Integração com API
      // await fetch(`/api/admin/usuarios/${usuarioToDelete.id}`, {
      //   method: 'DELETE',
      // })

      toast({
        title: "Usuário excluído!",
        description: `${usuarioToDelete.nome_completo} foi removido com sucesso.`,
      })

      handleCloseDeleteDialog()
      await refetchUsuarios()
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : "Ocorreu um erro ao excluir o usuário."
      console.error("❌ Erro ao excluir usuário:", error)
      toast({
        title: "Erro ao excluir",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header simples como página de logs */}
      <div className="bg-[#1E1E1E] border-b-4 border-[#F5C800] px-6 py-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3 uppercase">
              <Shield className="h-8 w-8 text-[#F5C800]" />
              Administração de Usuários
            </h1>
            <p className="text-[#F5C800] mt-2 text-sm uppercase font-medium">
              Gerencie usuários e permissões do sistema
            </p>
          </div>
          
          {/* Botão Novo Usuário */}
          <Button
            onClick={handleOpenCreateModal}
            className="h-12 bg-[#F5C800] text-[#1E1E1E] hover:bg-[#F5C800]/90 font-bold shadow-lg hover:shadow-xl transition-all px-6 rounded-lg"
          >
            <Plus className="h-5 w-5 mr-2" />
            Novo Usuário
          </Button>
        </div>
      </div>

      <div className="px-6 py-6">

        {/* Conteúdo - Tabela */}
        <Card className="shadow-lg border-0 rounded-xl overflow-hidden">
          <CardContent className="p-0">
            <UsuariosTable
              usuarios={usuarios}
              onEdit={handleOpenEditModal}
              onDelete={handleOpenDeleteDialog}
              isRefreshing={isRefreshing}
            />
          </CardContent>
        </Card>
      </div>

      {/* Modal de Usuário */}
      <UsuarioModal
        usuario={selectedUsuario}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
      />

      {/* Dialog de Exclusão */}
      <UsuarioDeleteDialog
        usuario={usuarioToDelete}
        isOpen={isDeleteDialogOpen}
        onClose={handleCloseDeleteDialog}
        onConfirm={handleConfirmDelete}
        isDeleting={isDeleting}
      />
    </div>
  )
}
