"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { Loader2, User, Shield, Eye, Plus, Trash2, LayoutDashboard, Users, Building2, DollarSign } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import type { Usuario, PermissoesUsuario } from "@/lib/types"

interface UsuarioModalProps {
  usuario?: Usuario | null
  isOpen: boolean
  onClose: () => void
}

const permissoesDefault: PermissoesUsuario = {
  dashboard: { view: true },
  clientes: { view: false, create: false, delete: false },
  obras: { view: false, create: false, delete: false },
  financeira: { view: false, create: false, delete: false },
}

export function UsuarioModal({ usuario, isOpen, onClose }: UsuarioModalProps) {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("informacoes")

  const [formData, setFormData] = useState({
    login: "",
    cargo: "funcionario" as "admin" | "funcionario",
    ativo: true,
    senha: "",
    confirmarSenha: "",
  })

  const [permissoes, setPermissoes] = useState<PermissoesUsuario>(permissoesDefault)

  // Resetar formulário quando modal abrir/fechar
  useEffect(() => {
    if (isOpen) {
      setActiveTab("informacoes")
      if (usuario) {
        // Modo edição
        setFormData({
          login: usuario.email || "", // Usar email como login por enquanto
          cargo: usuario.cargo || "funcionario",
          ativo: usuario.ativo ?? true,
          senha: "",
          confirmarSenha: "",
        })
        // TODO: Buscar permissões do usuário do backend
        setPermissoes(permissoesDefault)
      } else {
        // Modo criação
        setFormData({
          login: "",
          cargo: "funcionario",
          ativo: true,
          senha: "",
          confirmarSenha: "",
        })
        setPermissoes(permissoesDefault)
      }
    }
  }, [isOpen, usuario])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleCargoChange = (value: string) => {
    setFormData(prev => ({ ...prev, cargo: value as "admin" | "funcionario" }))
  }

  const handlePermissaoChange = (
    modulo: keyof PermissoesUsuario,
    acao: string,
    checked: boolean
  ) => {
    setPermissoes(prev => ({
      ...prev,
      [modulo]: {
        ...prev[modulo],
        [acao]: checked,
      },
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Validação básica
      if (!formData.login) {
        throw new Error("Login é obrigatório")
      }

      if (!usuario && !formData.senha) {
        throw new Error("Senha é obrigatória para novos usuários")
      }

      if (formData.senha && formData.senha.length < 4) {
        throw new Error("Senha deve ter no mínimo 4 caracteres")
      }

      if (formData.senha !== formData.confirmarSenha) {
        throw new Error("As senhas não coincidem")
      }

      const usuarioData = {
        login: formData.login,
        cargo: formData.cargo,
        ativo: formData.ativo,
        ...(formData.senha && { senha: formData.senha }),
        permissoes: permissoes,
      }

      console.log("📤 Dados do usuário a serem salvos:", usuarioData)
      console.log("Modo:", usuario ? "EDIÇÃO" : "CRIAÇÃO")

      // TODO: Integração com API
      // if (usuario) {
      //   await fetch(`/api/admin/usuarios/${usuario.id}`, {
      //     method: 'PUT',
      //     headers: { 'Content-Type': 'application/json' },
      //     body: JSON.stringify(usuarioData),
      //   })
      // } else {
      //   await fetch('/api/admin/usuarios', {
      //     method: 'POST',
      //     headers: { 'Content-Type': 'application/json' },
      //     body: JSON.stringify(usuarioData),
      //   })
      // }

      toast({
        title: usuario ? "Usuário atualizado!" : "Usuário criado!",
        description: usuario 
          ? `${formData.login} foi atualizado com sucesso.`
          : `${formData.login} foi criado com sucesso.`,
      })

      onClose()
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : "Ocorreu um erro ao salvar o usuário."
      console.error("❌ Erro ao salvar usuário:", error)
      toast({
        title: "Erro ao salvar",
        description: errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[650px] max-h-[85vh] overflow-hidden flex flex-col p-0">
        <DialogHeader className="pb-4 pt-6 px-6 border-b border-gray-200 flex-row items-center justify-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[#F5C800] flex items-center justify-center flex-shrink-0 shadow-md">
            <Shield className="h-6 w-6 text-[#1E1E1E]" strokeWidth={2.5} />
          </div>
          <DialogTitle className="text-xl sm:text-2xl font-bold text-[#1E1E1E]">
            {usuario ? "Editar Usuário" : "Novo Usuário"}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex flex-col flex-1 overflow-hidden">
          <div className="flex justify-center px-6 mt-4">
            <TabsList className="inline-flex w-auto bg-gray-100 h-12 rounded-lg">
              <TabsTrigger 
                value="informacoes"
                className="data-[state=active]:bg-[#F5C800] data-[state=active]:text-[#1E1E1E] font-semibold transition-all rounded-lg px-6"
              >
                <User className="h-4 w-4 mr-2" />
              Informações
            </TabsTrigger>
            <TabsTrigger 
              value="permissoes"
              className="data-[state=active]:bg-[#F5C800] data-[state=active]:text-[#1E1E1E] font-semibold transition-all rounded-lg px-6"
            >
              <Shield className="h-4 w-4 mr-2" />
              Permissões
            </TabsTrigger>
          </TabsList>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
            {/* ABA: INFORMAÇÕES */}
            <TabsContent value="informacoes" className="space-y-4 mt-4 overflow-y-auto flex-1 px-6 pb-2">
              <div className="grid gap-4">
                {/* Login */}
                <div className="space-y-2">
                  <Label htmlFor="login" className="font-semibold">
                    Login <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="login"
                    name="login"
                    value={formData.login}
                    onChange={handleInputChange}
                    placeholder="Ex: joao.silva"
                    required
                    disabled={isLoading || !!usuario}
                    className="border-2 focus:border-[#F5C800]"
                  />
                </div>

                {/* Senha */}
                <div className="space-y-2">
                  <Label htmlFor="senha" className="font-semibold">
                    Senha {!usuario && <span className="text-red-500">*</span>}
                  </Label>
                  <Input
                    id="senha"
                    name="senha"
                    type="password"
                    value={formData.senha}
                    onChange={handleInputChange}
                    placeholder={usuario ? "Deixe em branco para não alterar" : "Mínimo 4 caracteres"}
                    required={!usuario}
                    minLength={4}
                    disabled={isLoading}
                    className="border-2 focus:border-[#F5C800]"
                  />
                </div>

                {/* Confirmar Senha */}
                <div className="space-y-2">
                  <Label htmlFor="confirmarSenha" className="font-semibold">
                    Confirmar Senha {!usuario && <span className="text-red-500">*</span>}
                  </Label>
                  <Input
                    id="confirmarSenha"
                    name="confirmarSenha"
                    type="password"
                    value={formData.confirmarSenha}
                    onChange={handleInputChange}
                    placeholder={usuario ? "Deixe em branco para não alterar" : "Confirme a senha"}
                    required={!usuario}
                    minLength={4}
                    disabled={isLoading}
                    className="border-2 focus:border-[#F5C800]"
                  />
                </div>

                {/* Cargo */}
                <div className="space-y-2">
                  <Label htmlFor="cargo" className="font-semibold">
                    Cargo <span className="text-red-500">*</span>
                  </Label>
                  <Select
                    value={formData.cargo}
                    onValueChange={handleCargoChange}
                    disabled={isLoading}
                  >
                    <SelectTrigger className="border-2 focus:border-[#F5C800]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="funcionario">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4" />
                          Funcionário
                        </div>
                      </SelectItem>
                      <SelectItem value="admin">
                        <div className="flex items-center gap-2">
                          <Shield className="h-4 w-4" />
                          Administrador
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>

            {/* ABA: PERMISSÕES */}
            <TabsContent value="permissoes" className="mt-4 overflow-y-auto flex-1 py-5 px-6">
              <div className="space-y-4">
                {/* Dashboard */}
                <div className="border-2 border-[#F5C800]/60 rounded-xl p-5 bg-[#1E1E1E] hover:border-[#F5C800] hover:shadow-xl hover:shadow-[#F5C800]/20 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#F5C800] flex items-center justify-center shadow-md">
                        <LayoutDashboard className="h-5 w-5 text-[#1E1E1E]" strokeWidth={2.5} />
                      </div>
                      <div>
                        <h3 className="font-bold text-base text-white">
                          Dashboard
                        </h3>
                        <p className="text-xs text-gray-300 mt-0.5">Acesso à página inicial</p>
                      </div>
                    </div>
                    <Checkbox
                      id="dashboard-view"
                      checked={permissoes.dashboard.view}
                      onCheckedChange={(checked) =>
                        handlePermissaoChange("dashboard", "view", checked as boolean)
                      }
                      disabled={isLoading}
                      className="h-5 w-5 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                    />
                  </div>
                </div>

                {/* Clientes */}
                <div className="border-2 border-[#F5C800]/60 rounded-xl p-5 bg-[#1E1E1E] hover:border-[#F5C800] hover:shadow-xl hover:shadow-[#F5C800]/20 transition-all">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-[#F5C800] flex items-center justify-center shadow-md">
                      <Users className="h-5 w-5 text-[#1E1E1E]" strokeWidth={2.5} />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-white">Clientes</h3>
                      <p className="text-xs text-gray-300 mt-0.5">Gerenciamento de clientes</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <label className="flex items-center gap-2 p-2.5 rounded-lg border border-[#F5C800]/30 bg-black/30 hover:border-[#F5C800] hover:bg-black/50 cursor-pointer transition-colors">
                      <Checkbox
                        id="clientes-view"
                        checked={permissoes.clientes.view}
                        onCheckedChange={(checked) =>
                          handlePermissaoChange("clientes", "view", checked as boolean)
                        }
                        disabled={isLoading}
                        className="h-4 w-4 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                      />
                      <div className="flex items-center gap-1.5">
                        <Eye className="h-3.5 w-3.5 text-[#F5C800]" />
                        <span className="text-xs font-semibold text-white">Ver</span>
                      </div>
                    </label>
                    <label className="flex items-center gap-2 p-2.5 rounded-lg border border-[#F5C800]/30 bg-black/30 hover:border-[#F5C800] hover:bg-black/50 cursor-pointer transition-colors">
                      <Checkbox
                        id="clientes-create"
                        checked={permissoes.clientes.create}
                        onCheckedChange={(checked) =>
                          handlePermissaoChange("clientes", "create", checked as boolean)
                        }
                        disabled={isLoading}
                        className="h-4 w-4 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                      />
                      <div className="flex items-center gap-1.5">
                        <Plus className="h-3.5 w-3.5 text-[#F5C800]" />
                        <span className="text-xs font-semibold text-white">Criar</span>
                      </div>
                    </label>
                    <label className="flex items-center gap-2 p-2.5 rounded-lg border border-[#F5C800]/30 bg-black/30 hover:border-[#F5C800] hover:bg-black/50 cursor-pointer transition-colors">
                      <Checkbox
                        id="clientes-delete"
                        checked={permissoes.clientes.delete}
                        onCheckedChange={(checked) =>
                          handlePermissaoChange("clientes", "delete", checked as boolean)
                        }
                        disabled={isLoading}
                        className="h-4 w-4 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                      />
                      <div className="flex items-center gap-1.5">
                        <Trash2 className="h-3.5 w-3.5 text-[#F5C800]" />
                        <span className="text-xs font-semibold text-white">Deletar</span>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Obras */}
                <div className="border-2 border-[#F5C800]/60 rounded-xl p-5 bg-[#1E1E1E] hover:border-[#F5C800] hover:shadow-xl hover:shadow-[#F5C800]/20 transition-all">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-[#F5C800] flex items-center justify-center shadow-md">
                      <Building2 className="h-5 w-5 text-[#1E1E1E]" strokeWidth={2.5} />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-white">Obras</h3>
                      <p className="text-xs text-gray-300 mt-0.5">Gerenciamento de obras</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <label className="flex items-center gap-2 p-2.5 rounded-lg border border-[#F5C800]/30 bg-black/30 hover:border-[#F5C800] hover:bg-black/50 cursor-pointer transition-colors">
                      <Checkbox
                        id="obras-view"
                        checked={permissoes.obras.view}
                        onCheckedChange={(checked) =>
                          handlePermissaoChange("obras", "view", checked as boolean)
                        }
                        disabled={isLoading}
                        className="h-4 w-4 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                      />
                      <div className="flex items-center gap-1.5">
                        <Eye className="h-3.5 w-3.5 text-[#F5C800]" />
                        <span className="text-xs font-semibold text-white">Ver</span>
                      </div>
                    </label>
                    <label className="flex items-center gap-2 p-2.5 rounded-lg border border-[#F5C800]/30 bg-black/30 hover:border-[#F5C800] hover:bg-black/50 cursor-pointer transition-colors">
                      <Checkbox
                        id="obras-create"
                        checked={permissoes.obras.create}
                        onCheckedChange={(checked) =>
                          handlePermissaoChange("obras", "create", checked as boolean)
                        }
                        disabled={isLoading}
                        className="h-4 w-4 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                      />
                      <div className="flex items-center gap-1.5">
                        <Plus className="h-3.5 w-3.5 text-[#F5C800]" />
                        <span className="text-xs font-semibold text-white">Criar</span>
                      </div>
                    </label>
                    <label className="flex items-center gap-2 p-2.5 rounded-lg border border-[#F5C800]/30 bg-black/30 hover:border-[#F5C800] hover:bg-black/50 cursor-pointer transition-colors">
                      <Checkbox
                        id="obras-delete"
                        checked={permissoes.obras.delete}
                        onCheckedChange={(checked) =>
                          handlePermissaoChange("obras", "delete", checked as boolean)
                        }
                        disabled={isLoading}
                        className="h-4 w-4 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                      />
                      <div className="flex items-center gap-1.5">
                        <Trash2 className="h-3.5 w-3.5 text-[#F5C800]" />
                        <span className="text-xs font-semibold text-white">Deletar</span>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Financeira */}
                <div className="border-2 border-[#F5C800]/60 rounded-xl p-5 bg-[#1E1E1E] hover:border-[#F5C800] hover:shadow-xl hover:shadow-[#F5C800]/20 transition-all">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-[#F5C800] flex items-center justify-center shadow-md">
                      <DollarSign className="h-5 w-5 text-[#1E1E1E]" strokeWidth={2.5} />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-white">Financeira</h3>
                      <p className="text-xs text-gray-300 mt-0.5">Gerenciamento financeiro</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <label className="flex items-center gap-2 p-2.5 rounded-lg border border-[#F5C800]/30 bg-black/30 hover:border-[#F5C800] hover:bg-black/50 cursor-pointer transition-colors">
                      <Checkbox
                        id="financeira-view"
                        checked={permissoes.financeira.view}
                        onCheckedChange={(checked) =>
                          handlePermissaoChange("financeira", "view", checked as boolean)
                        }
                        disabled={isLoading}
                        className="h-4 w-4 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                      />
                      <div className="flex items-center gap-1.5">
                        <Eye className="h-3.5 w-3.5 text-[#F5C800]" />
                        <span className="text-xs font-semibold text-white">Ver</span>
                      </div>
                    </label>
                    <label className="flex items-center gap-2 p-2.5 rounded-lg border border-[#F5C800]/30 bg-black/30 hover:border-[#F5C800] hover:bg-black/50 cursor-pointer transition-colors">
                      <Checkbox
                        id="financeira-create"
                        checked={permissoes.financeira.create}
                        onCheckedChange={(checked) =>
                          handlePermissaoChange("financeira", "create", checked as boolean)
                        }
                        disabled={isLoading}
                        className="h-4 w-4 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                      />
                      <div className="flex items-center gap-1.5">
                        <Plus className="h-3.5 w-3.5 text-[#F5C800]" />
                        <span className="text-xs font-semibold text-white">Criar</span>
                      </div>
                    </label>
                    <label className="flex items-center gap-2 p-2.5 rounded-lg border border-[#F5C800]/30 bg-black/30 hover:border-[#F5C800] hover:bg-black/50 cursor-pointer transition-colors">
                      <Checkbox
                        id="financeira-delete"
                        checked={permissoes.financeira.delete}
                        onCheckedChange={(checked) =>
                          handlePermissaoChange("financeira", "delete", checked as boolean)
                        }
                        disabled={isLoading}
                        className="h-4 w-4 border-[#F5C800] data-[state=checked]:bg-[#F5C800]"
                      />
                      <div className="flex items-center gap-1.5">
                        <Trash2 className="h-3.5 w-3.5 text-[#F5C800]" />
                        <span className="text-xs font-semibold text-white">Deletar</span>
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            </TabsContent>

            <DialogFooter className="mt-4 pt-4 px-6 pb-6 border-t flex-shrink-0">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
                className="border-2 hover:bg-gray-100"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                className="bg-[#F5C800] hover:bg-[#F5C800]/90 text-[#1E1E1E] font-bold min-w-[140px]"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>{usuario ? "Salvar Alterações" : "Criar Usuário"}</>
                )}
              </Button>
            </DialogFooter>
          </form>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
